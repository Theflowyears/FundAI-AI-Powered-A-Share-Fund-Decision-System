# FundAI · AI-Powered A-Share Fund Decision System

> 面向中国 A 股**场外基金**的 AI 量化决策系统。每个交易日收盘后自动运行：从财联社、东方财富、新浪等渠道
> 抓取并解析新闻，结合十年历史电报库与市场情绪数据提取事件语义、政策信号与题材热度；再融合均线、RSI、动量等
> 技术指标，形成**量化、消息、情绪三路评分**。系统按评分动态选基，在固定基准仓位与硬性上限内给出
> **买入 / 赎回 / 转换建议**，并执行均线减仓、峰值回撤冷却、组合止损等反应型风控
> （基金级止损/止盈自 v1.2.0 起是**可开关项，默认关闭**，理由与数据见 `README_TECH.md` §25）。
>
> **系统不代持资金、不自动下单**：每日建议由你本人在支付宝 / 天天基金执行，回填成交后系统自动记账、
> 结算方向命中率并持续校准。程序纪律：只能买卖场外普通基金（股票型 / 指数型 / 债券型均可），绝不直接买卖股票。

纯 Python 实现（核心零依赖），可选依赖 **AKShare**（`pip install akshare`）作为基金净值
数据源。数据主源为 **AKShare（场外基金净值，免费无配额）+ 智兔数服（指数 K 线，需在
`config.json` 自行填写 Token；不填则自动走东财通道）**，东财接口与本地缓存兜底。
自带 Web 可视化仪表盘、SQLite 账本、每日研判时间线、AI 选基轮动、分级风控、
**消息可视化人工筛选 + 算法词典学习与方向命中率（+DSH 本地搜索补全）**、回测与离线演示。

## 为什么“买基金”而不是“直接买股票”？（AI 的判断）

- 个股有最低佣金（约 5 元/笔）与卖出印花税，小额交易每次就要吃掉 1%+ 的成本；
  单票闪崩/停牌可能直接出局，而且需要每天盯盘，不符合“AI 托管式”的运行方式。
- 只拿一只宽基指数基金（如沪深300）又过于被动：它的涨跌基本只代表大盘 beta，
  与“做决策”这件事没有关系。
- 因此本系统的折中是：**保持只买场外基金的约束**，但把进攻标的的选择权交给 AI——
  进攻池：科创50（011609）、半导体芯片（008888）、证券公司（012700）、沪深300（005918）四只 C 类联接基金
  （C 类 0 申购费、持有满 7 天免赎回费、当日净值已扣销售服务费），
  AI 每日按 **20 日动量 + 主题分散**综合选出 top N 只不同板块进攻（默认 3 只，
  避免单押某一板块），大盘转弱时撤到债基（270049）+ 现金。
- **绩效一律用“同期沪深300 的相对表现 + 最大回撤”表述**，不用“多少钱变成多少钱”的说法：
  起始资金只是账户参数，与策略优劣无关，任何金额下结论都同比例成立。
  十年实证、四窗口独立回测与样本外复核见
  [`README_TECH.md`](README_TECH.md) §6 / §25，复现命令 `python data/decision_study.py --jobs 1`。
-  **口径警示：历史回测是“样本内”回放** —— `eq_base / rearm_days / 止盈线 / confidence_shrink` 等参数
  正是在同一段历史上调优出来的，只能说明过去；对未来的前瞻性有限，请勿直接外推（详见下节与文末免责声明）。
-  2026-09-09 审计修复口径后重新回放：候选池改为 **point-in-time 逐日重建**（只用“当日及之前”
  可见净值选池，不再拿今天挑好的池回放历史），并剔除“当天 15:05 前抓取的盘中假 bar”，
  数字与修复前的口径不可直接对比。

**回测口径与样本外说明**
- 想看更接近真实的视角，运行 `python app.py oos --months 12`：把回看窗口按时间切成
  **full（全窗）/ train（前段）/ test（后段）** 三段，test 用**当前固定参数**直接跑、不回头再调；
  整窗**连续回放**（train/test 不各自从起始资金重新累计指标），train/test 段收益以“段首前一交易日
  总资产”为基准，前 60 个交易日仅预热不计统计。
  结果打印并写入 `data/backtest_oos.json`（`source=live` 才可信，demo 仅流程演示）。
- **实测样例（真实数据，见 `data/backtest_oos.json`；2026-09-09 以延伸至 2018 的指数缓存重跑）**：
  full（2025-07-282026-09-09，274 日）**+44.7%**（沪深300 +10.8%）；train（前 178 日，至 2026-04-22）
  **+36.4%**（沪深300 +16.3%）；test（后 96 日，2026-04-23 起，近似样本外）**+6.1%**（沪深300 −4.7%）、
  回撤 14.9%。
  这段结果直白地说明：同窗调参的高收益（样本内）在后段并**没有**延续 —— 样本内数字应视为
  “这段历史上怎么走”，不是“未来会怎样”。
- 即便这样，如果参数曾在后段也被人工微调过，test 仍只算**近似样本外**；**真正的样本外验证 =
  本项目逐日实盘**（策略是否可用，由后续每日实盘的累计结果回答，而不是由历史回放承诺）。
- 想控制过拟合，最有效的不是继续在历史上调参，而是**少调参 + 长实盘**：参数一经定稿就只作必要修正，
  更多交给每日实盘积累。
-  **历史行情与消息校准（2026-09 起新增）**
  - `python app.py fetch-history --years 8`：把主基准指数 K 线一次性延伸至 N 年写本地缓存
    （复用智兔/东财全区间单次请求；免费源 BaoStock 在本机装包受限，效果等价、无强依赖），
    长窗口回测用 `python app.py oos --months 24/36`；
  - 消息侧不做“黑箱训练”，而是**逐日积累可审计样本**：每天收盘后运行
    `python app.py signals-update`，把当日事件语义标签（央行宽松/地缘冲突/业绩/减持/
    ETF 产品风险提示…）结算成“消息下一交易日沪深300 涨跌”，样本够多后
    `python app.py signals-report` 输出每类事件真实命中率，据此微调规则强度；
  - 财联社电报接口需动态签名、历史无法自动回溯：在浏览器手动导出的电报
    json/jsonl 可用 `python app.py cls-import --file x.json --date YYYY-MM-DD` 并入样本。

## 版本更新 v1.2.1 / What's new（2026-11-06）

文档与产品口径修正，不涉及交易算法：

- **移除"以起始金额推算目标金额与涨幅"式叙述**：门面与技术文档里所有把账户起点
  换算成某个目标数字、并据此描述成败的表述已删除。本系统是一个**量化基金决策工具**，
  不设收益目标；`account.initial_cash`、`target_multiple` / `target_value`、观察期
  都只是**账户与界面显示参数**，不参与选基、仓位、风控的任何计算。
- **LLM 提示词不再携带收益目标**：旧版系统提示词把"在半年内把账户做到某个金额"
  写成了受托职责，这会诱导模型为凑数字给建议。现改为纯粹的风险与纪律表述；
  每日数据包里的"账户计划"字段也不再给出目标线与百分比。回归锁：`tests/test_account_plan.py::LlmPromptTest`。
- **绩效一律用相对基准 + 最大回撤表述**，不用"多少钱变成多少钱"：起点金额与策略优劣无关。
- **历史提交中的智兔 token 已清除**（重写全部 27 个提交，`config.json` 的
  `zhitu_token` 在所有历史版本中均为空值）。⚠️ 由于该 token 曾长期公开，
  请仍然把它当作已泄露并到服务商处轮换；仓库另有 PR ref，GitHub 侧缓存无法由我们清除。
- 339 项测试全绿；`tools/verify_release.py` 12 项检查通过（含从 ZIP / wheel 内起服务与跑测试）。

## 版本更新 v1.2.0 / What's new（2026-11-06）

本版把**资金分配**从启发式升级为可解释的约束组合构建，并用真实基金级引擎
（十年、四窗口、年度分解、时间顺序留出段）重跑了默认参数。**结论不是全面变好**，
下面把代价一起写清。

### 决策与组合层

- 新增 `fundai/portfolio.py`：`equal` 等权 / `inv_vol` 逆波动 /
  `min_var` 收缩协方差最小方差 / `adaptive` 制度自适应；
  统一套单基金上限 45%、同主题上限 70%、起购额、整数元，数据不足回退等权，
  并输出权重、金额、事前年化波动与集中度（HHI）到每日决策文案。
- **默认 `adaptive`**：趋势上行（沪深300 20 日动量 > 0 且评分 ≥ 25）用旧动量加权
  集中强势主题；其余状态等权分散。`adaptive_signal` 可切 `ma_align`/`mom20`/`either`。
- **基金级止损/止盈改为两个开关并默认关闭**（`fund_stop_loss_enable`、
  `fund_take_profit_enable`）；指数级均线减仓、峰值回撤冷却、组合止损、硬上限全部保留。
- 默认仓位从 **基准 90% / 硬上限 95% 调整为 80% / 80%**。
- 选基因子权重**没有改**（纯 20 日动量档实测全历史 +151.5% 但回撤 25.1% 越界、
  牛市段只有 +6.1%，不足以支持改动）。

### 实测（真实基金级引擎，2017-09-28 → 2026-11-05，同一份数据同一口径）

| 指标 | 旧策略 | v1.2.0 默认 |
|---|---:|---:|
| 全历史收益 / 最大回撤 | +75.7% / 24.1% | **+187.0% / 21.4%** |
| 时间切分留出段（2023-09→2026-11） | +46.7% | **+82.0%** |
| 牛市窗口（2020-03→2021-01） | **+25.5%** | +16.4% |
| 近 12 个月（2025-09→2026-11） | **+6.9%** | −1.9% |

**代价必须一起读**：新默认在**牛市反弹初期**和**近 12 个月这段行情**都跑输旧策略。
`mom20` 确认趋势需要约 20 个交易日，急跌后的 V 型反弹里它会先用等权，稀释最强主题；
如果未来重演近端这种行情，请不要期待 v1.2.0 更好。想回到旧行为，
参数面板把 `portfolio_method` 设回 `legacy`、两个基金级开关打开即可（配置有备份与回滚）。
完整表格、年度分解与复现命令见技术文档 **§25**（`README_TECH.md`）。

### 两处口径修复（会改变历史回测数字）

- `Engine.simulate` 现在与 `run_daily` 一样注入 `ma_align`/`vol_rank`：
  此前**回放看不到制度状态**，自适应与调整带在回测里会静默退化成等权。
- `data/harness.py` 的缓存签名原本盯 `kline_000300.SH.json`，实际落盘名是
  `kline_000300_SH.json`，签名恒为无效 → 研究窗口长期停在旧日期、与实盘回测口径不一致。
  修复后本报告全部数字重算（旧文档里 “90% 档回撤 30.4%” 之类数字即来自这个失效缓存）。

### 数据与安全

- 不再跟踪个人运行时数据：`data/fund200.db`（及其 .bak）、`data/screening.db`、
  `data/pool_state.json`、`data/signals_update.log` 已移出仓库并写进 `.gitignore`；
  `data/config_backups/`、`data/live.db`、`data/cls_history.db` 同样永不提交。
- 仓库内 `config.json` / `config.example.json` 的 `zhitu_token`、`llm.api_key` 一律为空。
- ⚠️ 历史提交中曾包含一个智兔 token，请视为已泄露并轮换。
- 测试确定性修复：`test_api_usage` 里一条用例原先依赖本机净值缓存深度
  （新克隆会失败），现钉住预期通道链。当前 **338 项测试全绿**，
  发行包另经 `tools/verify_release.py` 12 项检查（含从 ZIP/wheel 内起服务与跑测试）。

### 研究复现

```bash
python data/decision_study.py --jobs 1        # 15 变体 × 5 窗口 + 年度分解
python data/decision_study.py --jobs 1 --windows full,recent --only live,legacy_live
```

## 版本更新 v1.1.0 / What's new（2026-09-27）

本版把此前分开开发的两条线合并为一：一条以事件语义、命中率校准与每日结算为主，另一条模块与工具更完整。
下面是合并后这条 main 上实际存在的内容。

### 新增模块

- `fundai/api_usage.py`、`fundai/param_docs.py`、`fundai/microstructure.py`、`fundai/risk_overlay.py`
- `fundai/event_model.py`、`fundai/calib_history.py`、`fundai/configedit.py`
- `fundai/llm_news.py`、`fundai/intraday.py`、`fundai/starter.py`
- 研究脚本：`data/combo_study.py`、`data/micro_study.py`、`data/reactive_study.py`、`data/regime_study.py`、
  `data/news_direction_study.py`、`data/weight_combo_study.py`、`data/regime_backtest.py`、
  `data/audit.py`、`data/audit_web.py`

### 工具链与发布

- `tools/`：`make_release.py`、`verify_release.py`、`redact_for_github.py`、`clean_personal_data.py`、
  `audit_all.py`、`gen_starter.py`、`bench_parallel.py`、`backfill_direction_20260911.py`、`prepare_test_tmp.py`
- 便携打包：`MANIFEST.in`、`README_PORTABLE.md`、`README_TECH.md`、`config.example.json`

### 测试

测试文件共 18 个，跑法不变：

```sh
python -m pytest
```

### 本次合并进来的提交

- chore: sync local working copy (2026-09-09 line)
- feat(ui): 事件命中率校准可视化(/api/calibration + 消息与进化页表格/指数历史/一键延伸8年历史), fmtPctS 等前端支持; 38 tests
- fix(stability): 长驻服务默认禁用 akshare(有智兔token时)规避 py_mini_racer V8 崩溃 + save_json 并发写重试
- ops(daily): 计划任务 fundai_daily_signals 每交易日20:30跑样本结算(signals-update, refresh先补当日收盘bar)+包装bat
- feat(calib): 消息次日涨跌 样本库与命中率校准管线(signals-update/report)、财联社手动电报导入(cls-import)、纯逻辑评估测试; 38 tests
- feat(history): fetch-history 命令把主基准指数K线延伸至8年(智兔/东财全区间单次,缓存2018-09至今1945根)+长窗口OOS验证(24个月521统计日)+README样例刷新
- feat(news semantics): 事件语义推断层(semantics.py: 地缘冲突/央行宽松/业绩/减持/ETF产品风险提示 等可解释归因+AI依据理由)、入库 auto_reason/event_type 列(兼容旧库迁移)、产品风险提示不再误学词典、存量行 reapply 重算; 36 tests
- feat(positions): 持仓盈亏独立刷新按钮——强制在线重取持仓基金净值(force_live 绕过快照/TTL缓存)、新增 POST /api/positions/refresh、前端局部重渲染+toast净值日; 29 tests
- feat(news/lexicon): 严格术语化(只学FIN_TERMS完整词，杜绝滑窗碎片)+打标分流(AI采纳明确方向,人工额度≤50中性)+前端折叠覆盖/待确认过滤; lexicon重建20词; 29 tests
- feat(news/screening): 入库前模糊去重(长标题≥28字相似≥0.93，避开不同基金模板的0.85区)+未打标优先排序/todo统计, 存量清理5条无关行; 28 tests pass
- feat(news/lexicon): 术语化学习(FIN_TERMS 白名单+扩展≤2字)、打标前相关性预筛、近7天归一化标题入库去重、akshare 瞬时失败回退(连续4次才停用)、消息分 ±25 限幅可配 + 26 tests
- fix(engine): auto_confirm fills carry shares/amount fields (was latent KeyError in decision text); verified on live-copy run-daily
- chore(audit): tests(20) + settings param validation + demo backtest guard + snapshot/records trimming + README numbers under corrected PIT/warmup 口径
- fix(audit): P0-1 feed id/cache schema, P0-2 partial-bar kline, P0-3 PIT backtest+warmup, P0-4 ledger money/consistency, P0-5 reverse orders, P1-6 calendar, P1-8 auto_confirm/fill/revoke, P1-9 snapshot cache, P1-10 url redact

> 合并说明：两条历史没有共同祖先，同名文件在合并时取的是**文件时间较新**的那一份
> （`app.py`、`fundai/engine.py`、`fundai/datasource.py`、`fundai/strategy.py`、`fundai/web.py`、
> `web/static/app.js` 等 26 个）。对照 PR #2 的 diff 可以复核这些文件是否漏掉了较完整那条上的改动。

## 一、快速开始

```bat
cd <project-dir>\fund200ai
%LOCALAPPDATA%\Python\bin\python.exe app.py init     :: 初始化账户（起始资金与期限可自定义）
%LOCALAPPDATA%\Python\bin\python.exe app.py serve    :: 启动界面  http://127.0.0.1:8787
```

> 注意：本机 `python` 是 Windows 应用商店存根（敲了只会弹商店，不真执行），
> **请始终用完整路径** `%LOCALAPPDATA%\Python\bin\python.exe`（桌面 .bat 快捷方式已自动指向它），
> 或安装一个稳定的 Python ≥3.9 并加入 PATH。不确定时运行
> `python app.py doctor`（会自动提示是否存根、环境是否齐全）。

**每个交易日（约 20:00 净值公布后）运行一次**：

```bat
%LOCALAPPDATA%\Python\bin\python.exe app.py run-daily
```

或网页点 **【立即运行今日研判】**。

###  场外基金 T+1 时间要点（建议文案里也会写明）

> **为什么是「盘后给策略」而不是「盘中」？** 场外基金一天只有一个净值、且按**当日收盘净值**成交：
> 无论你盘中还是盘后下单，成交价都是收盘价，盘中不存在“以盘中价抄底/逃顶”。而本策略的全部信号
> （指数收盘价、基金净值、20 日动量、止损止盈）也都只在**收盘后**才齐全。盘中给建议 =
> 用不完整数据做决策 + 造成“我能盘中择时”的错觉，反而更容易追涨杀跌。所以最优抉择是**盘后给策略**：
> AI 用当日完整收盘数据研判，你从容地在**下一交易日 15:00 前**执行，预期清晰、不慌。

- AI 的建议在**收盘后**生成，所以对应的成交时点永远是**下一交易日**；
- **申购**：下一交易日 15:00 前在支付宝/天天基金提交  按当日收盘净值成交，T+1 晚可查份额；
  15:00 后提交或逢节假日  顺延到再下一个交易日；
- **锁仓**：从确认日起持有满 **7 个自然日**再赎回才免惩罚费（<7 天收 1.5%；C 类第 8 天起为 0）；
- **赎回/转换**：下一交易日 15:00 前提交  按当日净值确认赎回；资金到账以平台为准
  （债基约 T+1，权益基金一般 T+1~T+3）。AI 换基默认走**『基金转换』**：赎回与申购**同日配对
  下单**，你在支付宝/天天基金用“转换/超级转换”一次操作完成（转出与转入同一交易时点确认），
  **没有“先赎回等资金到账再买”的空窗期**；仅当平台不支持该对基金转换时才退化为两步
  （先赎回  资金到账  下一交易日盘后再给买入建议）；
- **自动 T+1 确认（跟支付宝一致）**：你在支付宝/天天基金执行后，回网页「指令与成交」
  点 **“我已在支付宝/天天基金提交”** 即可；系统记入“已提交·待T+1确认”缓存，
  按你提交时间自动推算净值成交日（15:00 前=当日、15:00 后=下一交易日）与份额确认日，
  到确认日运行「立即运行今日研判」即**自动按净值确认份额入账**，无需再手动填份额/净值。
- 想先离线看效果：`python app.py demo && python app.py serve --demo`（合成数据，只读）。

## 二、命令行一览

| 命令 | 说明 |
|---|---|
| `python app.py init [--reset] [--cash 1000]` | 初始化/重置正式账户 |
| `python app.py run-daily [--force]` | 当日研判 + 今日建议（收盘后执行） |
| `python app.py state` | 打印账户状态 JSON |
| `python app.py serve [--demo] [--port]` | 启动可视化界面 |
| `python app.py backtest --months 6 [--source auto\|live\|demo]` | 回测策略（样本内回放） |
| `python app.py oos --months 12 [--source live]` | 时间切分回测：full/train/test，近似样本外 |
| `python app.py refresh-pool [--force]` | 从候选中动态重建备选池（≥15 只：14 进攻 + 基准 + 债基） |
| `python app.py news-pull [--date] [--force]` | 多源拉取当日消息并入“消息与进化”库 |
| `python app.py search-queue` | 查看待 DSH 本地搜索补全的清单 |
| `python app.py search-import` | 合并 DSH 本地搜索回填结果（自动幂等） |
| `python app.py doctor` | 环境体检（解释器存根/图表库/配置口径） |
| `python app.py vendor-echarts` | 联网把 ECharts 内置到本地（离线画图） |
| `python app.py demo` | 生成演示库（合成行情，只读） |
| `python tools/check_fund.py 011609 270049` | 校验基金代码/名称/净值 |
| `python tools/search_fund.py 半导体` | 搜索基金扩充进攻池 |

## 三、每日运行流程

1. **盘后复盘（量化+消息面）**：智兔拉取沪深300 日K与进攻池基金净值，计算 MA5/20/60、
   RSI、动量、量比  打出 **-100~+100 量化分**；同时抓取**当日市场快讯**（东财快讯，
   公开接口）做利好/利空关键词相关性过滤与情绪打分（净情绪阻尼 ±8），
   按 **量化65% + 消息35%** 合成最终评分（配置 DeepSeek Key 后可由大模型基于两者撰写研判全文）；
2. **总仓位**：合成评分  权益目标仓位 `eq_base + eq_slope×评分`（默认 60% + 0.5pp/分，封顶 95%）；
3. **风控层（严格止损止盈，先于一切进攻）**：
   - 单只浮亏 ≤ -8%  【止损】清仓；单只浮盈 ≥ +10%  【止盈】卖一半；≥ +25%  全部落袋为安；
   - 总资产较本金亏 ≥ 15%  【组合止损】权益 ≤ 25%；自历史峰值回撤 ≥ 10% 且评分 < 25
      【峰值回撤】跟踪止盈降到 25% 权益；
   - 单只止损/止盈卖出后当日仍允许按规则继续调仓（可同步经『基金转换』换入强势板块，
     不留资金空窗）；组合级风控（组合止损/峰值回撤）触发当天只防守不进攻；
   - 组合止损/峰值回撤触发后进入 **`risk.rearm_days`（默认 7 个交易日）防御冷却期**：
     期间权益目标强制 ≤25%、只减不加，避免“止损次日又追涨”的来回打脸；
     **但冷却期内若【再次触发单只止损/止盈】或【市场评分 > 50】 例外放行当日**，
     允许直接调仓（`risk.allow_rearm_trade=false` 可关闭此例外）；
   - 不足 7 天份额默认等解锁再卖（risk.allow_early_exit_fee=true 则付 1.5% 费强制执行）；
4. **选基**：动态进攻池（≥15 只：14 进攻 + 1 基准 + 1 债基、每周按动量重建）内按
   **20 日动量 + 主题分散**综合选出 top N 只（默认 3 只、同主题最多 1 只，避免单押某一板块）；
   持仓明显落后组合才轮动，且默认用
   **『基金转换』一步完成**（赎回+申购同日配对  平台一次转换，无资金到账空窗；
   `strategy.use_fund_convert=false` 可退回“先赎旧  到账  次日买新”两步走）；
   当日已止损/止盈的基金剔除出候选（尊重止损纪律，次日重新评估）；
5. **下单纪律**：T+1 生效、持有 <7 天不可赎回（1.5% 惩罚费率）、单笔 ≥10 元、金额取整到元；
6. **展示**：仪表盘顶部**大盘指数条**（上证/深成/创业板/沪深300/科创50/中证500，红涨绿跌，
   沪深300 标注“基准”；新浪腾讯东财三源兜底、45 秒缓存，界面轮询不烧配额）；
   资产曲线 vs 同起点沪深300（另可叠加自定的进度基准线）、每日评分柱、消息面/风控记录、
   选基调仓历史、指令与成交台账。

## 四、数据源（默认 AKShare + 智兔，均可换）

- **基金净值：AKShare（默认）** —— `config.json  data.provider = "akshare"`，
  经 `pip install akshare` 后免费、无配额使用（内部走东财/天天基金公开源）；
  实测三只基金净值与智兔逐条一致。akshare 未安装/不可用时自动降级智兔东财。
- **指数：智兔数服**（`zhitu_token` 已内置，基址 `https://api.zhituapi.com`，
  限每日 200 次/频率 300 次每分，仅指数场景每天只需几次调用），失败自动降级东财直连。
- 程序节流：进程内 15 分钟冷却 + 磁盘缓存，界面轮询不消耗配额；
  用量在网页顶部与「设置」页可见（akshare 通道显示“免费不限”）。
- 想换回纯智兔：`data.provider = "zhitu"`；纯东财：`= "eastmoney"` 并清空 token。
  全部离线时用本地缓存；再不行用演示数据。

## 五、模拟盘 vs 人工执行

`config.json  account.exec_mode`：
- `"manual"`（默认）：AI 只给“今日建议”，订单挂起等你在支付宝执行后录入 —— 建议即操作；
- `"auto"`：模拟自动按次日净值成交（仅演示流程用，不会真实扣款）。

## 五·五、激进/保守档位（strategy 参数，可随时改后重启）

当前为**激进档**（中性也保持 60% 权益）：`eq_base=0.60`（中性仓位）、
`eq_slope=0.005`（评分每±1分仓位±0.5pp）、`eq_floor=0.10`、`eq_cap=0.95`、
`regime_step=0.10`（更灵敏调仓）、`bond_buy_floor=0.12`（机动现金 12%）、
`rotate_gap=0.05`（换基更勤）。
想回归稳健：把 `eq_base` 改回 `0.50`、`eq_cap` 改回 `0.92`、`bond_buy_floor` 改回 `0.20`。
注意：越激进收益弹性越大，回撤也越大，请自己接受对应风险。

**防抖/防御参数（新增）**：
- `risk.rearm_days=7`：组合止损/峰值回撤后的防御冷却**交易日数**（越大越稳，0=关闭）。
- `risk.allow_rearm_trade=true`：冷却期内允许“例外放行”——**再触发单只止损/止盈** 或
  **评分 > risk.rearm_bull_score(默认 50)** 时当日解除只防守限制、可直接调仓（改 false 则
  冷却期内一律只减不加）。
- `strategy.use_fund_convert=true`：轮动/换基走**基金转换**（赎回+申购同日配对、一次完成），
  改 false 退回两步走。
- `score_ema_enabled=false`：可选开启「评分 EMA 平滑」进一步降低换手（`score_ema_alpha`
  越大越跟手；平滑会牺牲一点趋势灵敏度，默认关闭，收益/回撤更平衡）。

## 六、动态备选基金池（任何时候 ≥15 只）

备选池是**动态调整**的，两层机制保证数量与质量：

1. **内置起步池（10 只）**：8 只进攻型权益 C 类（科创50/半导体芯片/证券/军工/通信/电子/
   人工智能/沪深300 等主题）+ 1 只沪深300基准（005918）+ 1 只债基底仓（270049 广发纯债C），
   全部 0 申购费、7 天后免赎回费；
2. **自动动态重建**（`config.json → screening`）：默认每 7 天（或点网页“立即重建备选池”/
   `python app.py refresh-pool`）从当前 **53 只候选基金**（`screening.universe`，可自行增删）里按
   **20 日动量**重选出 **top_equity=14 只进攻标的**（同主题最多 2 只），并附加规则：
   - 总数始终 **≥ min_total(15)**，不足自动用内置池补齐；
   - **当前持仓永远保留**（不会把你已持有的基金踢出池）；
   - 债基永远保留做防御（1 只）；
   - 每日例行若发现池过期/不足会自动顺延重试（智兔配额不足时次日再试）。

筛选结果存于 `data/pool_state.json`，界面「设置动态备选基金池」可查看数量/来源/更新时间并一键重建。
想调更勤：改 `screening.refresh_days`；想换候选：编辑 `screening.universe`（代码来自
`tools/search_fund.py` 搜索 + `tools/check_fund.py` 校验）。

## 六·五、消息与进化：可视化人工筛选 + 算法学习 + 搜索补全

新增顶部页签 **「消息与进化」**，把“消息面”从黑盒变成“你看得见、能纠错、越用越懂你”的模块：

**1. 广域采集与联动**
- 多源拉取：东财快讯 + 新浪 7x24（任一失败自动跳过、全部失败才报错），去重合并；
- 每条消息自动打标（利好/利空/中性/与市场无关 + 强度），并识别命中板块主题、
  联动到备选池里对应的候选基金（消息基金联动，筛选时直接看到“这条影响哪只基金”）。

**2. 每日人工筛选（可视化）**
- 网页逐条复核：点「重大利好/利好/中性/利空/重大利空/与市场无关」即可覆盖自动判断；
- 当天方向打标 ≥1 条后，**当日研判的消息分改用“人工消息分”**（净情绪按打标强度汇总，
  阻尼与自动分一致），研判文案会标注“消息面[人工筛选]”。

**3. 算法自我学习与进化**
- 每次打标即增量重算**学习词典**：从“你判为利好/利空的正文”里自动挖出高频、方向一致、
  且基础词典没有的新词（中文 2~6 字 n-gram，自动剪枝重叠子串与噪音）；
- 学习词叠加进**以后的自动打分**（`data/screening.db` 持久化），即“算法记住你的判断标准”；
- 网页可查看学到的词与多空样本数；删掉 `data/screening.db` 可一键重置学习。

**4. AI 自动方向研判 & 自检命中率**
- **次日大盘方向由 AI 自动研判并记录**（按当日合成评分看多/看空/中性 + 信心），
  **无需你来预测**；你只负责标记消息价值与过滤；
- 引擎在下一交易日收盘后**自动结算 AI 命中率**并展示（总/分方向命中率/历史记录），
  用来检验整套“消息加权+打分”是否靠谱。

**5. DSH 本地搜索补全（API 抓不齐时）**
- 在线消息太少/抓取失败时，系统自动写 **`data/search_queue.json`**（待补清单，含 query 与原因）；
  网页「登记搜索补全清单」或 `python app.py search-queue` 可查看；
- 由 DSH 助手用本地搜索（Bing/百度）跑这些 query，把结果写回 **`data/search_results.json`**：
  ```json
  {"results": [{"queue_id": "…", "ok": true,
    "items": [{"title": "…", "snippet": "…", "url": "…", "time": "…"}]}]}
  ```
- 网页「合并搜索回填结果」（或下次 `run-daily` / `python app.py search-import`）
  自动把搜索结果打标后并入当天消息库（source=本地搜索回填，幂等不重复）。

> 注意：回测/演示为**纯量化回放**，不套用人工标签与学习词，保证口径可比；学习只影响
> 正式库“以后每天”的自动打分。每日操作路径：**收盘后  网页拉取今日消息  逐条打标
> （价值与过滤） 运行“立即运行今日研判”**（AI 方向与命中率自动结算）。

## 七、免责声明

本程序仅供视频创作与学习研究：研判/建议/回测均为自动生成，不构成投资建议。
本系统是一个**量化基金决策工具**：它的产出是每日研判、选基与仓位建议、风控纪律和可复盘的账本，
**不设任何收益目标，也不承诺收益倍数**；行情不佳时策略会先求“少亏”再求“进攻”。
界面里的“目标线/进度”只是一个**可自定义的显示基准**（`account.target_multiple` 等），
不构成策略目标，也不参与任何交易决策。基金有风险，请勿使用生活必需资金参与。

## 八、开机自启与桌面快捷方式（本机已配置）

- **后台服务**：`data/fund200.db` 的仪表盘服务（http://127.0.0.1:8787）已做成无窗口后台进程
  （`fundai_start_hidden.py`，由 pythonw 运行，事件记录在 `data/server_autostart.log`）；
- **开机自启**：快捷方式已放入用户“启动”文件夹
  `…\Start Menu\Programs\Startup\fundai_serve.lnk`（登录后自动拉起）；
- **保活兜底**：Windows 计划任务 `fundai_keepalive` 每 15 分钟检查一次，服务不在就自动拉起。
   **必须用 `pythonw.exe`（无控制台）运行** `fundai_start_hidden.py`；切勿用
  `cmd /c python ...` 或 `fundai_start.bat` 做计划任务——否则每 15 分钟会闪一个 CMD 黑框再秒关。
  重建无窗口保活：
  `schtasks /Create /TN fundai_keepalive /SC MINUTE /MO 15 /TR "…\pythonw.exe …\fundai_start_hidden.py"`
- **桌面入口**：
  - `FundAI-仪表盘.url` —— 双击直接用默认浏览器打开仪表盘；
  - `AI基金-启动后台服务.lnk` —— 双击手动启动/重启后台服务（已在运行则无动作）；
- **如何关闭自启**：删除启动文件夹里的 `fundai_serve.lnk`；
  删除计划任务：`schtasks /Delete /TN fundai_keepalive /F`；
  停后台进程：任务管理器结束 `pythonw.exe`（或先删任务再结束进程）。

