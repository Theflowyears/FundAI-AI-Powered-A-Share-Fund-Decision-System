# -*- coding: utf-8 -*-
"""测试环境判定：区分「源码树」与「发行包」。

为什么要这层：
  便携包/轮子**故意不携带** `config.json`、数据库、缓存（含密钥与 GB 级数据）。
  但有一部分测试是在**校验本部署的具体取值**（"线上是不是固定 70%""参数元数据是否
  覆盖了当前 config.json 的全部叶子键"）——这类断言在干净环境里没有意义，
  应当 **skip 并说明原因**，而不是失败或删掉：源码树里它们仍然强制执行。

用法：
    from _env import needs_config, needs_data
    @needs_config
    def test_xxx(self): ...
"""
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
HAS_CONFIG = (ROOT / "config.json").exists()

needs_config = unittest.skipUnless(
    HAS_CONFIG, "需要真实 config.json（发行包不含，见 README_PORTABLE.md）")


def needs_data(name):
    """依赖某个数据产物（如 data/regime_windows.json）的用例。"""
    return unittest.skipUnless(
        (ROOT / "data" / name).exists(),
        "需要数据产物 data/{}（发行包不含）".format(name))
