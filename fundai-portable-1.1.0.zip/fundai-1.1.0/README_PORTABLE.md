# fundai 便携包 · 3 步上手

> 1000 元基金实验的完整程序：AI 每日研判 + 十七年实证回测 + 网页可视化 + 参数开关面板。
> **不含任何密钥、数据库与缓存**，解压即属于你自己的一套干净环境。

## 1. 环境要求

* Windows 10/11
* Python **3.9+**（3.11–3.14 均可），安装时勾选 “Add Python to PATH”
* 可选：`pip install numpy`（事件模型与情绪回补快约 10 倍；不装自动回退，结果一致）

## 2. 三步跑起来

```bat
:: ① 环境自检（解释器、依赖、数据口径）
python app.py doctor

:: ② 起网页（默认 http://127.0.0.1:8787）
启动服务.bat            :: 或： python app.py serve

:: ③ 收盘后跑一次研判（生成每日建议；你按建议在支付宝/天天基金手动执行）
python app.py run-daily
```

首次运行会**自动生成 `config.json`**（含一套通用起始基金池：宽基指数 + 行业指数 + 债基）。
想改参数不用手写 JSON：打开网页 → **设置 → 🎛 参数开关面板**（126 个参数都带中文说明，
17 个开关，改动自动备份、可一键回滚）。

## 3. 配置你的数据源（可选但推荐）

`config.json` → `data.zhitu_token` 填智兔数服的 Token（免费额度 200 次/天），
或直接留空走东财/新浪公开通道。填了之后：

```bat
python app.py fetch-history --years 8     :: 拉取指数长历史（回测用）
python app.py news-fetch-db --days 30     :: 回填财联社电报（消息面用）
python app.py news-score-db               :: 按线上口径给库内电报打分
```

**数据源用量与降级状态在网页可见**：设置页 → 🛰 数据源与配额（分源调用数、剩余额度、
当前供货通道、降级原因、近 14 天用量、通道切换记录）；一旦降级，仪表盘顶部会弹告警。

## 4. 每日自动化（可选）

```bat
install_tasks.bat      :: 右键“以管理员身份运行” → 注册 5 个计划任务
```

注册内容：保活（每 15 分钟）、午间诊断（工作日 12:00）、样本结算（工作日 20:30）、
每日研判（21:30）、兜底补跑（22:45）。

## 5. 复现全部实证结论

```bat
python -m unittest discover -s tests -p "test_*.py"   :: 219 项测试
python data/harness.py            :: 划分牛市/熊市/震荡市三组留出期
python data/regime_study.py --dd 25                   :: 25% 回撤上限下的 6000 组组合扫描
python data/regime_backtest.py    :: 基金级四窗口回测 + 子系统阉割对比 + 最终组合
python data/news_direction_study.py                   :: 消息面方向性实测
```

## 6. 目录说明

| 目录 | 内容 |
|---|---|
| `fundai/` | 主包（算法、引擎、数据源、Web、配置元数据、计数与降级） |
| `web/static/` | 前端（原生 JS + 本地 ECharts，离线可用） |
| `data/` | 运行期数据：账本、消息库、缓存、研究脚本与结论 JSON（首次运行自动创建） |
| `tests/` | 219 项测试（含"重启不清零""回放完整性""配置写入端"等回归用例） |
| `tools/` | 打包与验证脚本（`make_release.py` / `verify_release.py` / `gen_starter.py`） |
| `dist/` | 发行产物（wheel / sdist / 便携 ZIP） |

## 7. 免责声明

本程序仅用于研究、教学与视频创作：所有研判、建议、回测与命中率均为程序自动生成，
**不构成任何投资建议**。市场有风险，请勿直接据此进行真实资金操作。
